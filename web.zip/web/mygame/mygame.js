nav = new SceneNavigator(["startup"]);
	stats = {
		looc: "Кругом заботоченный лес. "
		,inper: "df"
		,tact: 1
			};