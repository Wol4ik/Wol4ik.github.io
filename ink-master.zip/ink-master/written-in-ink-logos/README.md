# Written in ink logos

We'd be delighted if you would like to include one of the *Written in ink* logos in your game or other creative work. You can find them below.

You can also find the [inkle logos on our press page](https://www.inklestudios.com/press/).

<https://github.com/inkle/ink/blob/master/written-in-ink-logos/written-in-ink-on-white-only.png>

![](https://github.com/inkle/ink/blob/master/written-in-ink-logos/written-in-ink-on-white-only.png)

<https://github.com/inkle/ink/blob/master/written-in-ink-logos/written-in-ink-black-mid-and-colour.png>

![](https://github.com/inkle/ink/blob/master/written-in-ink-logos/written-in-ink-black-mid-and-colour.png)

