﻿namespace Ink.Runtime
{
    internal class Void : Runtime.Object
    {
        public Void ()
        {
        }
    }
}

