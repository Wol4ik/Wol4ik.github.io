Choice Script
============

Sublime Text 2/3 syntax highlighting for Choice Script

[Choice Script](https://github.com/dfabulich/choicescript)

[Choice of Games](http://www.choiceofgames.com/make-your-own-games/choicescript-intro/)


Install:

Prefered installation through package control https://github.com/wbond/sublime.wbond.net

Manual Install:
  1. From Sublime text go to preferences and then browse packages.
  2. Drag and drop the files included in the zip into that directory.
  3. Do not put them in a folder just place them all alone.
